﻿using backend_api.Dto;
using backend_api.Entities;
using backend_api.Interface;
using backend_api.Repository;

namespace backend_api.Service
{
    public class ProductService : IProduct
    {
        private readonly IRepository<Product> _productRepository;
        public ProductService(IRepository<Product> productRepository)
        {
            _productRepository = productRepository;
        }
        public async Task Add(ProductDto model)
        {
            var addProduct = new Product
            {
                Name = model.Name,
                Description = model.Description,
                CategoryId = model.CategoryId,
                Price = model.Price,
                Quantity = model.Quantity,
                SKU = model.SKU,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };
            await _productRepository.Create(addProduct).ConfigureAwait(true);
        }

        public async Task<Product> Get(string productId)
        {
            return await _productRepository.Find(p => p.ProductId.ToString() == productId);
        }

        public async Task<IEnumerable<Product>> GetAll()
        {
            return await _productRepository.GetAll();
        }

        public async Task Remove(Product model)
        {
            await Task.Run(() => _productRepository.Delete(model));
        }

        public async Task Update(string productId,ProductDto model)
        {
            var product = await _productRepository.Find(p => p.ProductId.ToString() == productId);
            product.Name = model.Name;
            product.Description = model.Description;
            product.Price = model.Price;
            product.Quantity = model.Quantity;
            product.SKU = model.SKU;
            product.UpdatedAt = model.UpdatedAt;
        
            await Task.Run(() => _productRepository.Update(product));
        }
    }
}
