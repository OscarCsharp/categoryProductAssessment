﻿using backend_api.Dto;
using backend_api.Entities;
using backend_api.Interface;
using backend_api.Repository;

namespace backend_api.Service
{
    public class CategoryService : ICategory
    {
        private readonly IRepository<Category> _categoryRepository;
        public CategoryService(IRepository<Category> categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }
        public async Task Add(CategoryDto model)
        {
            var addCategory = new Category
            {
                Name = model.Name,
                Description = model.Description,
                ParentCategoryId = model.ParentCategoryId
            };
            await _categoryRepository.Create(addCategory).ConfigureAwait(true);
        }

        public async Task<Category> Get(string CategoryId)
        {
            return await _categoryRepository.Find(p => p.CategoryId.ToString() == CategoryId);
        }

        public async Task<IEnumerable<Category>> GetAll()
        {
            return await _categoryRepository.GetAll();
        }

        public async Task Remove(Category model)
        {
            await Task.Run(() => _categoryRepository.Delete(model));
        }

        public async Task Update(string CategoryId, CategoryDto model)
        {
            var category = await _categoryRepository.Find(p => p.CategoryId.ToString() == CategoryId);
            category.Name = model.Name;
            category.Description = model.Description;
            category.ParentCategoryId = model.ParentCategoryId;

            await Task.Run(() => _categoryRepository.Update(category));
        }
    }
}
