﻿using System.Linq.Expressions;

namespace backend_api.Repository
{
    public interface IRepository<TEntity> where TEntity : class
    {
        Task<List<TEntity>> GetAll(Expression<Func<TEntity, object>>[] includeExpressions = null);
        Task<TEntity> Find(Expression<Func<TEntity, bool>> predicate);
        Task Create(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);
    }
}
