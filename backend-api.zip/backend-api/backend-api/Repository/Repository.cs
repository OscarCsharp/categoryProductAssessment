﻿using backend_api.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace backend_api.Repository
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class
    {

        private readonly DataContext context;
        private readonly DbSet<TEntity> entities;

        public Repository(DataContext _context)
        {
            context = _context;
            entities = _context.Set<TEntity>();
        }

        public async Task<List<TEntity>> GetAll(Expression<Func<TEntity, object>>[] includeExpressions = null)
        {
            IQueryable<TEntity> query = entities;
            if (includeExpressions != null)
            {
                foreach (var expression in includeExpressions)
                {
                    query = query.Include(expression);
                }
            }
            return await query.ToListAsync();
        }

        public async Task<TEntity> Find(Expression<Func<TEntity, bool>> predicate)
        {
            return await entities.FirstOrDefaultAsync(predicate);
        }

        public async Task Create(TEntity entity)
        {
            await context.AddAsync(entity);
            await context.SaveChangesAsync();
        }


        public void Update(TEntity entity)
        {
            entities.Attach(entity);
            context.Entry(entity).State = EntityState.Modified;
            context.SaveChanges();
        }

        public void Delete(TEntity entity)
        {
            entities.Remove(entity);
            context.SaveChanges();
        }

    }
}
