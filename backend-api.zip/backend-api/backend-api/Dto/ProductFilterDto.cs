﻿namespace backend_api.Dto
{
    public class ProductFilterDto
    {
        public int Name { get; set; } 
        public string Description { get; set; } = string.Empty;
        public int Page { get; set; } 
        public int PageSize { get; set; } 
    }
}
