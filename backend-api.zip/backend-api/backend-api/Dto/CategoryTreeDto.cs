﻿using backend_api.Dto;

namespace backend_api.Dto
{
    public class CategoryTreeDto
    {
        public int Id { get; set; } 
        public string Name { get; set; } = string.Empty ;
        public List<CategoryTreeDto>? ChildCategories { get; set; }
    }
}
