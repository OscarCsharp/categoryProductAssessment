﻿using backend_api.Dto;
using backend_api.Entities;
using backend_api.Interface;
using backend_api.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace backend_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategory _categoryService;

        public CategoriesController(ICategory categoryService)
        {
            _categoryService = categoryService;
        }

        [HttpGet]
        public async Task<ActionResult<CategoryDto>> GetFlatCategories()
        {

            var categories = await _categoryService.GetAll();
            var results = categories.Select(DTOMapping).ToList();

            return Ok(results);
        }

        [HttpGet("tree")]
        public async Task<ActionResult<IEnumerable<CategoryTreeDto>>> GetTreeCategories()
        {
            var categories = await _categoryService.GetAll();

            var categoryDict = categories.ToDictionary(c => c.CategoryId, c => new CategoryTreeDto
            {
                Id = c.CategoryId,
                Name = c.Name,
                ChildCategories = new List<CategoryTreeDto>()
            });

            List<CategoryTreeDto> treeCategories = new();

            foreach (var category in categories)
            {
                if (category.ParentCategoryId == null)
                {
                    treeCategories.Add(categoryDict[category.CategoryId]);
                }
                else if (categoryDict.ContainsKey(category.ParentCategoryId))
                {
                    categoryDict[category.ParentCategoryId].ChildCategories.Add(categoryDict[category.CategoryId]);
                }
            }

            return Ok(treeCategories);
        }

        [HttpPost]
        public async Task AddCategory(CategoryDto model)
        {
            await _categoryService.Add(model);
        }

        private CategoryDto DTOMapping(Category model)
        {
            return new CategoryDto
            {
                Id = model.CategoryId,
                Name = model.Name,
                Description = model.Description,
                ParentCategoryId = model.ParentCategoryId,
            };
        }
    }
}
