﻿using backend_api.Dto;
using backend_api.Entities;
using backend_api.Interface;
using backend_api.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json.Serialization;

namespace backend_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProduct _productService;

        public ProductsController(IProduct productService)
        {
            _productService = productService;
        }


        [HttpGet]
        public async Task<ActionResult<ProductDto>> GetProducts([FromQuery] string? searchTerm, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
        {
            var products = await _productService.GetAll();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                products = products.Where(a =>
                    (!string.IsNullOrWhiteSpace(searchTerm) && a.Name != null && a.Name.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)) ||
                    (!string.IsNullOrWhiteSpace(searchTerm) && a.Description != null && a.Description.Contains(searchTerm, StringComparison.OrdinalIgnoreCase))
                ).ToList();
            }

            products = products.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            var results = products.Select(DTOMapping).ToList();

            return Ok(results);
        }


        [HttpGet("{id}")]
        public async Task<IActionResult> GetProduct(string id)
        {
            var product = await _productService.Get(id);
            if (product == null) return BadRequest();
            return Ok(product);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(string id,ProductDto model)
        {
            var product = await _productService.Get(id);
            if (product == null) return BadRequest();
            await _productService.Update(id,model);
            return Ok();
        }

        [HttpPost]
        public async Task AddProduct(ProductDto model)
        {
            await _productService.Add(model);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(string id)
        {
            var product = await _productService.Get(id);
            if(product == null) return BadRequest();
            await _productService.Remove(product);
            return Ok();
        }


        private ProductDto DTOMapping(Product model)
        {
            return new ProductDto
            {
                Id = model.ProductId,
                Name = model.Name,
                Description = model.Description,
                CategoryId = model.CategoryId,
                SKU = model.SKU,
                Price = model.Price,
                Quantity = model.Quantity,
                CreatedAt = model.CreatedAt,
                UpdatedAt = model.UpdatedAt,
            };
        }


    }
}
