﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace backend_api.Entities
{
    public class Category
    {
        [Key]
        public int CategoryId { get; set; } 
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int ParentCategoryId { get; set; }
        public ICollection<Product>? Products;

    }
}
