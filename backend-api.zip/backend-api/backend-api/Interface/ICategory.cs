﻿using backend_api.Dto;
using backend_api.Entities;

namespace backend_api.Interface
{
    public interface ICategory
    {
        Task<IEnumerable<Category>> GetAll();
        Task Add(CategoryDto model);
        Task Remove(Category model);
        Task Update(string CategoryId, CategoryDto model);
        Task<Category> Get(string categoryId);
    }
}
