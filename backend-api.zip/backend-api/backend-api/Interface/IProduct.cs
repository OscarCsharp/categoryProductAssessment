﻿using backend_api.Dto;
using backend_api.Entities;

namespace backend_api.Interface
{
    public interface IProduct
    {
        Task<IEnumerable<Product>> GetAll();
        Task Add(ProductDto model);
        Task Remove(Product model);
        Task Update(string productId, ProductDto model);
        Task<Product> Get(string productId);
    }
}
