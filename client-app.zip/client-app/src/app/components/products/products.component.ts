import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../service/product.service';
import { SearchBarComponent } from "../search-bar/search-bar.component";
import { LoadingIndicatorComponent } from "../loading-indicator/loading-indicator.component";
import { CategoryFilterComponent } from "../category-filter/category-filter.component";
import { CategoryFormComponent } from "../category-form/category-form.component";
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { CategoryService } from '../../service/category.service';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, SearchBarComponent, LoadingIndicatorComponent, CategoryFilterComponent, CategoryFormComponent],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent implements OnInit {
  products: any[] = [];
  filteredProducts: any[] = [];
  loading = false;
  error = '';
  searchTerm = '';
  selectedCategoryId = '';
  page = 1;
  pageSize = 20;
  categories: any[] = [];

  constructor(private categoryService: CategoryService, private productService: ProductService, private router: Router) { }

  ngOnInit() {
    this.categoryService.getAll().subscribe({
      next: categoryData => {
        this.categories = categoryData;
        this.loadProducts();
      },
      error: err => {
        this.error = 'Failed to load categories';
      }
    });

  }

  loadProducts() {
    this.loading = true;
    this.productService.getFilteredProducts(this.searchTerm, this.page, this.pageSize).subscribe({
      next: data => {
        this.products = data.map(product => ({
          ...product,
          categoryName: this.getCategoryName(product.categoryId)
        }));
        this.filteredProducts = this.filterByCategory(this.selectedCategoryId);
        this.loading = false;
      },
      error: err => {
        this.error = 'Failed to load products';
        this.loading = false;
      }
    });
  }
  onSearch(term: string) {
    this.searchTerm = term;
    this.loadProducts();
  }

  onFilter(categoryId: any) {
    this.selectedCategoryId = categoryId;
    this.filteredProducts = this.filterByCategory(categoryId);
  }

  filterByCategory(categoryId: any): any[] {
    if (!categoryId) return this.products;
    return this.products.filter(p => p.categoryId === categoryId);
  }

  edit(product: any) {
    this.router.navigate(['/products/edit', product.id]);
  }

  confirmDelete(id: string) {
    if (confirm('Are you sure you want to delete this product?')) {
      this.productService.delete(id).subscribe(() => {
        this.products = this.products.filter(p => p.id !== id);
        this.filteredProducts = this.filteredProducts.filter(p => p.id !== id);
      });
    }
  }

  addProduct() {
    this.router.navigate(['/products/add']);
  }

  getCategoryName(categoryId: string): string {
    const category = this.categories.find(c => c.id === categoryId);
    return category ? category.name : 'Unknown';
  }

}