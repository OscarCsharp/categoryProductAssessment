import { Component, EventEmitter, Output } from '@angular/core';
import { CategoryService } from '../../service/category.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-category-filter',
  imports: [CommonModule],
  templateUrl: './category-filter.component.html',
  styleUrl: './category-filter.component.css'
})
export class CategoryFilterComponent {

@Output() filter = new EventEmitter<string>();
categories: any[] = [];

constructor(private categoryService: CategoryService) {}

ngOnInit() {
  this.categoryService.getAll().subscribe(data => {
    this.categories = data;
  });
}


onChange(event: Event) {
  const selectedId = (event.target as HTMLSelectElement).value;
  this.filter.emit(selectedId);
}



}
