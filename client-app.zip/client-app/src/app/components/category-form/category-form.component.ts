import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CategoryService } from '../../service/category.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-category-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './category-form.component.html',
  styleUrl: './category-form.component.css'
})
export class CategoryFormComponent {
  form: FormGroup;

  constructor(private fb: FormBuilder, private categoryService: CategoryService) {
    this.form = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      parentId: ['']
    });
  }

  submit() {
    if (this.form.valid) {
      const categoryData = {
        name: this.form.value.name,
        description: this.form.value.description,
        parentCategoryId: this.form.value.parentId || 0 // default to 0 if empty
      };

      this.categoryService.add(categoryData).subscribe(() => {
        alert('Category added!');
        this.form.reset();
      });
    }
  }
}