import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoryService } from '../../service/category.service';
import { ProductService } from '../../service/product.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css'], 
  imports: [CommonModule,ReactiveFormsModule]
})
export class ProductFormComponent implements OnInit {
  form!: FormGroup;
  categories: any[] = [];
  isEdit = false;

  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private categoryService: CategoryService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {

    this.form = this.fb.group({
      name: ['', Validators.required],
      description: [''],
      sku: [0, [Validators.required, Validators.min(1)]],
      categoryId: ['', Validators.required],
      price: [0, [Validators.required, Validators.min(0)]]
    });
    

    this.categoryService.getAll().subscribe(data => {
      this.categories = data;
    });

    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.productService.getById(id).subscribe(product => {
        this.form.patchValue(product);
      });
    }
  }

  submit(): void {
    if (this.form.invalid) return;

    const productData = this.form.value;

    if (this.isEdit) {
      const id = this.route.snapshot.paramMap.get('id');
      this.productService.update(id!, productData).subscribe(() => {
        this.router.navigate(['/products']);
      });
    } else {
      this.productService.add(productData).subscribe(() => {
        this.router.navigate(['/products']);
      });
    }
  }
}