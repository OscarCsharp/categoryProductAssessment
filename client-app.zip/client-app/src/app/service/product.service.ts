import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({ providedIn: 'root' })
export class ProductService {
  private apiUrl = 'https://localhost:7023/api/products';

  constructor(private http: HttpClient) {}

  
  getFilteredProducts(searchTerm: string, page: number, pageSize: number) {
    const params = {
      searchTerm: searchTerm || '',
      page: page.toString(),
      pageSize: pageSize.toString()
    };
  
    return this.http.get<any[]>(this.apiUrl, { params });
  }

  getById(id: string) {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  add(any: any) {
    return this.http.post<any>(this.apiUrl, any);
  }

  update(id: string, any: any) {
    return this.http.put<any>(`${this.apiUrl}/${id}`, any);
  }

  delete(id: string) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}